App.Application = DS.Model.extend({

});
